﻿# SDK Pullenti Address, version 4.14, september 2022. Copyright (c) 2013, Pullenti. All rights reserved.
# Non-Commercial Freeware and Commercial Software.
# This class is generated using the converter Unisharping (www.unisharping.ru) from Pullenti C# project.
# The latest version of the code is available on the site www.PullentiPython.ru

import io
from PullentiPython.unisharp.Utils import Utils

from PullentiPython.semantic.core.SemanticRole import SemanticRole
from PullentiPython.semantic.utils.ControlModelItemType import ControlModelItemType

class ControlModelItem:
    """ Элемент модели управления """
    
    def __init__(self) -> None:
        self.typ = ControlModelItemType.WORD
        self.word = None;
        self.links = dict()
        self.nominative_can_be_agent_and_pacient = False
        self.ignorable = False
    
    def __str__(self) -> str:
        res = io.StringIO()
        if (self.ignorable): 
            print("IGNORE ", end="", file=res)
        if (self.typ != ControlModelItemType.WORD): 
            print("{0}: ".format(Utils.enumToString(self.typ)), end="", file=res, flush=True)
        else: 
            print("{0}: ".format(Utils.ifNotNull(self.word, "?")), end="", file=res, flush=True)
        for li in self.links.items(): 
            if (li[1] == SemanticRole.AGENT): 
                print("аг:", end="", file=res)
            elif (li[1] == SemanticRole.PACIENT): 
                print("пац:", end="", file=res)
            elif (li[1] == SemanticRole.STRONG): 
                print("сильн:", end="", file=res)
            print("{0}? ".format(li[0].spelling), end="", file=res, flush=True)
        return Utils.toStringStringIO(res)