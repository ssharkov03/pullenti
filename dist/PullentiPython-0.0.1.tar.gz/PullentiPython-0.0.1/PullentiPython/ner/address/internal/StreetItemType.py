﻿# SDK Pullenti Address, version 4.14, september 2022. Copyright (c) 2013, Pullenti. All rights reserved.
# Non-Commercial Freeware and Commercial Software.
# This class is generated using the converter Unisharping (www.unisharping.ru) from Pullenti C# project.
# The latest version of the code is available on the site www.PullentiPython.ru

from enum import IntEnum

class StreetItemType(IntEnum):
    NOUN = 0
    NAME = 1
    NUMBER = 2
    STDADJECTIVE = 3
    STDNAME = 4
    STDPARTOFNAME = 5
    AGE = 6
    FIX = 7
    
    @classmethod
    def has_value(cls, value):
        return any(value == item.value for item in cls)