﻿# SDK Pullenti Address, version 4.14, september 2022. Copyright (c) 2013, Pullenti. All rights reserved.
# Non-Commercial Freeware and Commercial Software.
# This class is generated using the converter Unisharping (www.unisharping.ru) from Pullenti C# project.
# The latest version of the code is available on the site www.PullentiPython.ru

from PullentiPython.unisharp.Utils import Utils

from PullentiPython.ner.metadata.ReferentClass import ReferentClass
from PullentiPython.ner.keyword.KeywordType import KeywordType

class KeywordMeta(ReferentClass):
    
    @staticmethod
    def initialize() -> None:
        from PullentiPython.ner.keyword.KeywordReferent import KeywordReferent
        KeywordMeta.GLOBAL_META = KeywordMeta()
        KeywordMeta.GLOBAL_META.add_feature(KeywordReferent.ATTR_TYPE, "Тип", 1, 1)
        KeywordMeta.GLOBAL_META.add_feature(KeywordReferent.ATTR_VALUE, "Значение", 1, 0)
        KeywordMeta.GLOBAL_META.add_feature(KeywordReferent.ATTR_NORMAL, "Нормализация", 1, 0)
        KeywordMeta.GLOBAL_META.add_feature(KeywordReferent.ATTR_REF, "Ссылка", 0, 0)
    
    @property
    def name(self) -> str:
        from PullentiPython.ner.keyword.KeywordReferent import KeywordReferent
        return KeywordReferent.OBJ_TYPENAME
    
    @property
    def caption(self) -> str:
        return "Ключевое слово"
    
    IMAGE_OBJ = "kwobject"
    
    IMAGE_PRED = "kwpredicate"
    
    IMAGE_REF = "kwreferent"
    
    def get_image_id(self, obj : 'Referent'=None) -> str:
        from PullentiPython.ner.keyword.KeywordReferent import KeywordReferent
        m = Utils.asObjectOrNull(obj, KeywordReferent)
        if (m is not None): 
            if (m.typ == KeywordType.PREDICATE): 
                return KeywordMeta.IMAGE_PRED
            if (m.typ == KeywordType.REFERENT): 
                return KeywordMeta.IMAGE_REF
        return KeywordMeta.IMAGE_OBJ
    
    GLOBAL_META = None